#!/usr/bin/env python3
from brain_games.logic_even import welcome_user, game_even

def main():
    welcome_user()
    game_even()
    pass


if __name__ == '__main__':
    main()