### Hexlet tests and linter status:
[![Actions Status](https://github.com/galacticbox/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/galacticbox/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/39166e71281a7e6f86bc/maintainability)](https://codeclimate.com/github/galacticbox/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/m1pSZXuga2JGKeQiFGuX30lBQ.svg)](https://asciinema.org/a/m1pSZXuga2JGKeQiFGuX30lBQ)
[![asciicast](https://asciinema.org/a/vuNroc57BVB2qhXHVfxV0dqoI.svg)](https://asciinema.org/a/vuNroc57BVB2qhXHVfxV0dqoI)
[![asciicast](https://asciinema.org/a/q2Nhr7ttcBzlXkc3T66RY3Kpt.svg)](https://asciinema.org/a/q2Nhr7ttcBzlXkc3T66RY3Kpt)
[![asciicast](https://asciinema.org/a/daNYnrWkIKQwyYrl8ieAlZCjr.svg)](https://asciinema.org/a/daNYnrWkIKQwyYrl8ieAlZCjr)
[![asciicast](https://asciinema.org/a/3SJlnyOr7NPABUlboX8EToSbw.svg)](https://asciinema.org/a/3SJlnyOr7NPABUlboX8EToSbw)