# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/galacticbox/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/galacticbox/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/39166e71281a7e6f86bc/maintainability)](https://codeclimate.com/github/galacticbox/python-project-49/maintainability)\n[![asciicast](https://asciinema.org/a/m1pSZXuga2JGKeQiFGuX30lBQ.svg)](https://asciinema.org/a/m1pSZXuga2JGKeQiFGuX30lBQ)\n[![asciicast](https://asciinema.org/a/vuNroc57BVB2qhXHVfxV0dqoI.svg)](https://asciinema.org/a/vuNroc57BVB2qhXHVfxV0dqoI)\n[![asciicast](https://asciinema.org/a/q2Nhr7ttcBzlXkc3T66RY3Kpt.svg)](https://asciinema.org/a/q2Nhr7ttcBzlXkc3T66RY3Kpt)\n[![asciicast](https://asciinema.org/a/daNYnrWkIKQwyYrl8ieAlZCjr.svg)](https://asciinema.org/a/daNYnrWkIKQwyYrl8ieAlZCjr)',
    'author': 'Gala K',
    'author_email': 'step.by.step.jb@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
