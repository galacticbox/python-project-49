from random import randint, choice
from brain_games.common_logic import answering, winning

calc_sign = ['+', '-', '*']


def is_calc(x, y, z):
    if z == '+':
        return x + y
    elif z == '-':
        return x - y
    elif z == '*':
        return x * y


def game_calc():
    for _ in range(3):
        given_number_1 = randint(1, 20)
        given_number_2 = randint(1, 20)
        given_calc = choice(calc_sign)
        print(f'Question: {given_number_1} {given_calc} {given_number_2}')
        answer = int(input('Your answer: '))
        result = answering(is_calc(given_number_1, given_number_2, given_calc), answer)
        if result == False:
            break
    if result == True:
        winning()